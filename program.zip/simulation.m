clear
clc

lambda_su=0.4;
lambda_pu=0.25;
mu_su=0.8;
mu_pu=0.7;
su_num=8000;                      %��su����
pu_num=32000;                     %��pu����
theta_num=32000;                  %��theta����
free_num=32000;                   %�ܿ��и���
dd=1;
cd=1;
Parameter1=7;
Parameter2=2;


%-----------------------------------------------����Ϊtheta�Ĳ�ͬ�ĵ�����Ϊѭ��---------
for dt=1:1:10 
    sum1=0;
    sum2=0;
for ww=1:1:10 
    %---------------------------����Ϊ���õ�����������-------------------------------   
    su_arr_interval=exprnd(1/lambda_su,1,su_num);            %su����������ָ���ֲ�
    pu_arr_interval=exprnd(1/lambda_pu,1,pu_num);            %pu����������ָ���ֲ�
    su_serve_interval=exprnd(1/mu_su,1,su_num);              %su�������ָ���ֲ�
    pu_serve_interval=exprnd(1/mu_pu,1,pu_num);              %pu�������ָ���ֲ�
    theta=1/dt;
    theta_serve_interval=exprnd(1/theta,1,theta_num);        %theta�������ָ���ֲ� 
    su_arr_time=cumsum(su_arr_interval);                     %su����ʱ����һ�����飡����
    pu_arr_time=cumsum(pu_arr_interval);                     %pu����ʱ�����У�pu�ĵ���ʱ����˵��֮ǰpu���ʱ����ܺ� 
    %-----------------------------��ʼ��-------------------------------------- 
    su_beginser_time=zeros(1,su_num);                   %-------------------��ʼ�����ʱ����su_num+1��ֵ
    su_leave_time=zeros(1,su_num);                      %-------------------suʵ���뿪��ʱ������
    pu_leave_time=pu_arr_time+pu_serve_interval;        %-------------------pu�뿪��ʱ������
    theta_beginser_time=zeros(1,theta_num);             %-------------------��ʼ�����ʱ����theta_num+1��ֵ
    theta_leave_time=zeros(1,theta_num);                %-------------------thetaʵ���뿪��ʱ������
    free_arr_time=zeros(1,free_num);                    %-------------------���е�������ֵ           xinjia@oo@
    free_leave_time=zeros(1,free_num);                  %-------------------���������뿪������       xinjia@oo@
    t=1;                                                                         %%��ǰ�ݼٵ����
    pa=1;                               %pu�����ĳ�ʼֵ                           %%��ǰ��PU�����
    kx=1;                               %���и����ĳ�ʼֵ                         %%��ǰ���е����
    theta_beginser_time(1)=0;
    su_uneff=0;
    su_eff=0;
    pu_uneff=0;
    pu_eff=0;
%-----------------------------����-------------------------------------------
theta_leave_time(1)=theta_beginser_time(1)+theta_serve_interval(1);
if pu_arr_time(1)>su_arr_time(1)&&pu_arr_time(1)>theta_leave_time(1)%���1��pu����su������puδ�����ݼ���
        if  su_arr_time(1)>theta_leave_time(1)   %���1.1��su���ݼ���֮�󵽣�����������             
            su_beginser_time(1)=su_arr_time(1);
            free_arr_time(1)=theta_leave_time(1);           
            free_leave_time(1)=su_beginser_time(1);         
            kx=kx+1;                                        
        else                                     %���1.2��su���ݼ��ڽ�����
            su_beginser_time(1)=theta_leave_time(1);
        end
%----------------------------------------------------------------------------------        
elseif pu_arr_time(1)>su_arr_time(1)&&pu_arr_time(1)<theta_leave_time(1)%���2��pu����su������pu�����ݼ���
       theta_leave_time(1)=pu_arr_time(1); 
       pu_eff=pu_eff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
       su_beginser_time(1)=pu_leave_time(1);
       aa=find(pu_arr_time(2:pu_num)>pu_leave_time(1),1)-1;   
          for zuse=1:aa
              pa=pa+1;
              pu_leave_time(pa)=pu_arr_time(pa); 
              pu_uneff=pu_uneff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
          end
        pa=pa+1;                         %ע��pa��ָ����һ��������pu��kx��ָ����һ��������free��
%-------------------------------------------------------------------   
elseif pu_arr_time(1)<su_arr_time(1)%���3��pu����su��
    pu_eff=pu_eff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
    if pu_arr_time(1)<theta_leave_time(1)   %���3.1��pu�����ݼ���
       theta_leave_time(1)=pu_arr_time(1);
    else                                    %���3.2��puδ�����ݼ���
       free_arr_time(1)=theta_leave_time(1);               
       free_leave_time(1)=pu_arr_time(1);                  
       kx=kx+1;
    end
    aa=find(pu_arr_time(2:pu_num)>pu_leave_time(1),1)-1; %������pu����֮�䱻������pu�ĸ���
    for zuse=1:aa
        pa=pa+1;
        pu_leave_time(pa)=pu_arr_time(pa); 
        pu_uneff=pu_uneff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
    end  
    pa=pa+1; 
    hhh=pa;
    if su_arr_time(1)<pu_leave_time(1) %su��pu��ȥ֮ǰ����
       su_beginser_time(1)=pu_leave_time(1);
    else                               %su��pu��ȥ֮�󵽴�
       bb=0;
       while pu_arr_time(pa)<su_arr_time(1)
             pu_eff=pu_eff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
             t=t+1;
             if t==2;
                theta_beginser_time(t)=pu_leave_time(1);
             else
                theta_beginser_time(t)=pu_leave_time(pa-bb-1);%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�㿴���ǣ���ô���������أ�
             end
             theta_leave_time(t)=theta_beginser_time(t)+theta_serve_interval(t);
             if theta_leave_time(t)>pu_arr_time(pa)
                theta_leave_time(t)=pu_arr_time(pa);
             else
                free_arr_time(kx)=theta_leave_time(t);                
                free_leave_time(kx)=pu_arr_time(pa);                  
                kx=kx+1;                                              
             end
             bb=find(pu_arr_time(pa+1:pu_num)>pu_leave_time(pa),1)-1; 
             for zuse=1:bb
                 pa=pa+1;
                 pu_leave_time(pa)=pu_arr_time(pa); 
                 pu_uneff=pu_uneff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
             end
             pa=pa+1;
       
             if pu_leave_time(pa-bb-1)>su_arr_time(1)
                su_beginser_time(1)=pu_leave_time(pa-bb-1);
                break;
             end 
      end%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
        if (pu_arr_time(pa)>su_arr_time(1))&&(pu_leave_time(pa-bb-1)<su_arr_time(1))
           t=t+1;
           if pa==hhh
               theta_beginser_time(t)=pu_leave_time(pa-aa-1);
           else
           theta_beginser_time(t)=pu_leave_time(pa-bb-1);
           end
           theta_leave_time(t)=theta_beginser_time(t)+theta_serve_interval(t);
           if theta_leave_time(t)<pu_arr_time(pa)
              if  theta_leave_time(t)>su_arr_time(1);
                  su_beginser_time(1)=theta_leave_time(t);
              else
                 su_beginser_time(1)=su_arr_time(1);
                 free_arr_time(kx)=theta_leave_time(t);        
                 free_leave_time(kx)=su_beginser_time(1);      
                 kx=kx+1;
              end
           else
              pu_eff=pu_eff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
              theta_leave_time(t)=pu_arr_time(pa);                                          
              su_beginser_time(1)=pu_leave_time(pa);
              aa=find(pu_arr_time(pa+1:pu_num)>pu_leave_time(pa),1)-1;                                        
              for zuse=1:aa
                  pa=pa+1;
                  pu_leave_time(pa)=pu_arr_time(pa); 
                  pu_uneff=pu_uneff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
              end
              pa=pa+1;  
           end 
        end
    end
end%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%���޸���������
  %-----------------------------��su����Ϊѭ��-----------------------------------
for s=1:(su_num-1)
    su_leave_time(s)=su_beginser_time(s)+su_serve_interval(s);
    if su_leave_time(s)>pu_arr_time(pa)%su���ж�
       su_leave_time(s)=pu_arr_time(pa);
       pu_eff=pu_eff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
       su_uneff=su_uneff+1;
       pp=find(pu_arr_time(pa+1:pu_num)>pu_leave_time(pa),1)-1;%�ұ�������PU
       for zuse=1:pp
           pa=pa+1;
           pu_leave_time(pa)=pu_arr_time(pa);
           pu_uneff=pu_uneff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
       end
       pa=pa+1;
       qq=find(su_arr_time(s+1:su_num)>pu_leave_time(pa-pp-1),1)-1;%����û�к�����su����
       if qq>0    %���к�����su�������Խ��ŷ���        
          su_beginser_time(s+1)=pu_leave_time(pa-pp-1);
       else       %���޺�����su�������Խ����ݼٷ���
          t=t+1;
          theta_beginser_time(t)=pu_leave_time(pa-pp-1);
          theta_leave_time(t)=theta_beginser_time(t)+theta_serve_interval(t);
          if pu_arr_time(pa)>su_arr_time(s+1)&&pu_arr_time(pa)>theta_leave_time(t)
             if su_arr_time(s+1)>theta_leave_time(t)                
                su_beginser_time(s+1)=su_arr_time(s+1);
                free_arr_time(kx)=theta_leave_time(t);           
                free_leave_time(kx)=su_beginser_time(s+1);         
                kx=kx+1;                                        
             else
                su_beginser_time(s+1)=theta_leave_time(t);
             end
%--------------------------------------------------------------------------     
          elseif pu_arr_time(pa)>su_arr_time(s+1)&&pu_arr_time(pa)<theta_leave_time(t)
              theta_leave_time(t)=pu_arr_time(pa);                                                            
              su_beginser_time(s+1)=pu_leave_time(pa);
              pu_eff=pu_eff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
              aa=find(pu_arr_time(pa+1:pu_num)>pu_leave_time(pa),1)-1;                                                             
              for zuse=1:aa
                  pa=pa+1;
                  pu_leave_time(pa)=pu_arr_time(pa); 
                  pu_uneff=pu_uneff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
              end
              pa=pa+1; 
%-------------------------------------------------------------------   
          elseif pu_arr_time(pa)<su_arr_time(s+1) 
                 pu_eff=pu_eff+1;
                 if pu_arr_time(pa)<theta_leave_time(t)
                    theta_leave_time(t)=pu_arr_time(pa);
                 else 
                    free_arr_time(kx)=theta_leave_time(t);               
                    free_leave_time(kx)=pu_arr_time(pa);                  
                    kx=kx+1;
                 end
                 aa=find(pu_arr_time(pa+1:pu_num)>pu_leave_time(pa),1)-1; 
                 for zuse=1:aa
                     pa=pa+1;
                     pu_leave_time(pa)=pu_arr_time(pa); 
                     pu_uneff=pu_uneff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
                 end  
                 pa=pa+1; 
                 www=pa;
                 if su_arr_time(s+1)<pu_leave_time(pa-aa-1)
                    su_beginser_time(s+1)=pu_leave_time(pa-aa-1);
                 else 
                    bb=0;
                    linshi=t+1;
                    while pu_arr_time(pa)<su_arr_time(s+1)
                        pu_eff=pu_eff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
                        t=t+1;
                        if t==linshi;
                           theta_beginser_time(t)=pu_leave_time(pa-aa-1);
                        else
                           theta_beginser_time(t)=pu_leave_time(pa-bb-1);
                        end
                        theta_leave_time(t)=theta_beginser_time(t)+theta_serve_interval(t);
                        if theta_leave_time(t)>pu_arr_time(pa)
                           theta_leave_time(t)=pu_arr_time(pa);
                        else
                           free_arr_time(kx)=theta_leave_time(t);                
                           free_leave_time(kx)=pu_arr_time(pa);                  
                           kx=kx+1;                                              
                        end
                        bb=find(pu_arr_time(pa+1:pu_num)>pu_leave_time(pa),1)-1; 
                        for zuse=1:bb
                            pa=pa+1;
                            pu_leave_time(pa)=pu_arr_time(pa);
                            pu_uneff=pu_uneff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
                        end
                        pa=pa+1; 
                    
                        if pu_leave_time(pa-bb-1)>su_arr_time(s+1)
                           su_beginser_time(s+1)=pu_leave_time(pa-bb-1);
                           break;
                        end 
                        
                     end %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55  
                   if (pu_arr_time(pa)>su_arr_time(s+1))&&(pu_leave_time(pa-bb-1)<su_arr_time(s+1))
                      t=t+1;
                      if pa==www;
                         theta_beginser_time(t)=pu_leave_time(pa-aa-1);
                      else
                      theta_beginser_time(t)=pu_leave_time(pa-bb-1);
                      end
                      theta_leave_time(t)=theta_beginser_time(t)+theta_serve_interval(t);
                      if theta_leave_time(t)<pu_arr_time(pa)
                         if  theta_leave_time(t)>su_arr_time(s+1);
                             su_beginser_time(s+1)=theta_leave_time(t);
                         else
                             su_beginser_time(s+1)=su_arr_time(s+1);
                             free_arr_time(kx)=theta_leave_time(t);        
                           free_leave_time(kx)=su_beginser_time(s+1);      
                             kx=kx+1;
                         end
                      else
                         theta_leave_time(t)=pu_arr_time(pa);                                        
                         su_beginser_time(s+1)=pu_leave_time(pa);
                         pu_eff=pu_eff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
                         aa=find(pu_arr_time(pa+1:pu_num)>pu_leave_time(pa),1)-1;                                        
                         for zuse=1:aa
                             pa=pa+1;
                             pu_leave_time(pa)=pu_arr_time(pa);  
                             pu_uneff=pu_uneff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
                         end
                         pa=pa+1;  
                      end  
                   end
                 end
          end
       end
%����----------------------------------------------------------------------
    else                           %δ�ж�
       su_eff=su_eff+1;
       rr=find(su_arr_time(s+1:su_num)>su_leave_time(s),1)-1;
       if rr>0
          su_beginser_time(s+1)=su_leave_time(s); %���к�����su�������ʼ�������
       else 
          t=t+1;
          theta_beginser_time(t)=su_leave_time(s);
          theta_leave_time(t)=theta_beginser_time(t)+theta_serve_interval(t);
          if pu_arr_time(pa)>su_arr_time(s+1)&&pu_arr_time(pa)>theta_leave_time(t)
             if su_arr_time(s+1)>theta_leave_time(t)                
                su_beginser_time(s+1)=su_arr_time(s+1);
                free_arr_time(kx)=theta_leave_time(t);           
                free_leave_time(kx)=su_beginser_time(s+1);         
                kx=kx+1;                                        
             else
               su_beginser_time(s+1)=theta_leave_time(t);
             end
%----------------------------------------------------------------------------------        
           elseif pu_arr_time(pa)>su_arr_time(s+1)&&pu_arr_time(pa)<theta_leave_time(t)
                  pu_eff=pu_eff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  theta_leave_time(t)=pu_arr_time(pa);                                                            
                  su_beginser_time(s+1)=pu_leave_time(pa);
                  aa=find(pu_arr_time(pa+1:pu_num)>pu_leave_time(pa),1)-1;                                                             
                  for zuse=1:aa
                      pa=pa+1;
                      pu_leave_time(pa)=pu_arr_time(pa); 
                      pu_uneff=pu_uneff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  end
                  pa=pa+1; 
%-------------------------------------------------------------------   
            elseif pu_arr_time(pa)<su_arr_time(s+1) 
                   pu_eff=pu_eff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
                   if pu_arr_time(pa)<theta_leave_time(t)
                      theta_leave_time(t)=pu_arr_time(pa);
                   else 
                      free_arr_time(kx)=theta_leave_time(t);               
                      free_leave_time(kx)=pu_arr_time(pa);                  
                      kx=kx+1;
                   end
                   aa=find(pu_arr_time(pa+1:pu_num)>pu_leave_time(pa),1)-1; 
                   for zuse=1:aa
                       pa=pa+1;
                       pu_leave_time(pa)=pu_arr_time(pa);  
                       pu_uneff=pu_uneff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
                   end  
                   pa=pa+1; 
                   eee=pa;
                   if su_arr_time(s+1)<pu_leave_time(pa-aa-1)
                      su_beginser_time(s+1)=pu_leave_time(pa-aa-1);
                   else 
                      bb=0;
                      linshi=t+1;
                      while pu_arr_time(pa)<su_arr_time(s+1)
                           pu_eff=pu_eff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
                           t=t+1;
                           if t==linshi;
                              theta_beginser_time(t)=pu_leave_time(pa-aa-1);
                           else
                              theta_beginser_time(t)=pu_leave_time(pa-bb-1);
                           end
                           theta_leave_time(t)=theta_beginser_time(t)+theta_serve_interval(t);
                           if theta_leave_time(t)>pu_arr_time(pa)
                              theta_leave_time(t)=pu_arr_time(pa);
                           else
                              free_arr_time(kx)=theta_leave_time(t);                
                              free_leave_time(kx)=pu_arr_time(pa);                  
                              kx=kx+1;                                              
                           end
                           bb=find(pu_arr_time(pa+1:pu_num)>pu_leave_time(pa),1)-1; 
                           for zuse=1:bb
                               pa=pa+1;
                               pu_leave_time(pa)=pu_arr_time(pa); 
                               pu_uneff=pu_uneff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
                           end
                           pa=pa+1; 
                       
                           if pu_leave_time(pa-bb-1)>su_arr_time(s+1)
                              su_beginser_time(s+1)=pu_leave_time(pa-bb-1);
                              break;
                           end 
                      end%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                      if pu_arr_time(pa)>su_arr_time(s+1)&&(pu_leave_time(pa-bb-1)<su_arr_time(s+1))
                         t=t+1;
                         if pa==eee
                             theta_beginser_time(t)=pu_leave_time(pa-aa-1);
                         else
                         theta_beginser_time(t)=pu_leave_time(pa-bb-1);
                         end
                         theta_leave_time(t)=theta_beginser_time(t)+theta_serve_interval(t);
                         if theta_leave_time(t)<pu_arr_time(pa)
                            if  theta_leave_time(t)>su_arr_time(s+1);
                                su_beginser_time(s+1)=theta_leave_time(t);
                            else
                                 su_beginser_time(s+1)=su_arr_time(s+1);
                                 free_arr_time(kx)=theta_leave_time(t);        
                                 free_leave_time(kx)=su_beginser_time(s+1);      
                                 kx=kx+1;
                            end
                         else
                             pu_eff=pu_eff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
                             theta_leave_time(t)=pu_arr_time(pa);                                        
                             su_beginser_time(s+1)=pu_leave_time(pa);
                             aa=find(pu_arr_time(pa+1:pu_num)>pu_leave_time(pa),1)-1;                                        
                             for zuse=1:aa
                                 pa=pa+1;
                                 pu_leave_time(pa)=pu_arr_time(pa);
                                 pu_uneff=pu_uneff+1;%@@@@@@@@@@@@@@@@@@@@@@@@@@@
                             end
                             pa=pa+1;  
                         end
                      end
                   end
          end
       end
    end
end


total_time=su_beginser_time(su_num);


total_pu_time=0;%puռ�õ���ʱ��
for a=1:(pa-1)
    total_pu_time=total_pu_time+(pu_leave_time(a)-pu_arr_time(a));
end

total_su_time=0;%suռ�õ���ʱ��
for a=1:(su_num-1)
    total_su_time=total_su_time+(su_leave_time(a)-su_beginser_time(a));
end

total_serve_time=total_pu_time+total_su_time;%�ŵ���ռ�õ�ʱ��

total_theta_time=0;%�ݼٵ���ʱ��

for a=1:t
    total_theta_time=total_theta_time+(theta_leave_time(a)-theta_beginser_time(a));
end

total_free_time=0;%���е���ʱ��

for a=1:(kx-1)   
    total_free_time=total_free_time+(free_leave_time(a)-free_arr_time(a));
end
%  total_time=total_su_time+total_pu_time+total_theta_time+total_free_time;%��������������������������������������������������������
vvvvvvvvv=total_time-(total_su_time+total_pu_time+total_theta_time+total_free_time);
vvvvvvvvv


su_stay=su_leave_time-su_arr_time;
su_stay_time=0;
for i=1:(su_num-1)
    su_stay_time=su_stay_time+su_stay(i);
end

Pu.Block(dd)=pu_uneff/total_time;%pu�������ʣ�������������������������������
Su.Break(dd)=su_uneff/total_time;%su���ж��ʣ�������������������������
Occupy.Rate(dd)=total_serve_time/total_time;%�ŵ�ռ���ʣ�������������������������������
Vacation.Rate(dd)=Parameter1*(total_theta_time/total_time)-Parameter2*(total_theta_time/total_time)*(lambda_pu+theta);%�ݼ�ռ����  �����ȷ
Su.Throughput(dd)=(su_eff/total_time);%������!!!!!!!!!!!!!!!!!!!!!
Su.Stay(dd)=(su_stay_time)/(total_time*lambda_su);%su���ӳ� �����ȷ

sum1=sum1+Vacation.Rate(dd);
sum2=sum2+Su.Stay(dd);

dd=dd+1;
end

Rate.Vacation(cd)=sum1/10;
Stay.Su(cd)=sum2/10;
cd=cd+1;
end
box on;
hold on;
g=legend('��ֵʵ��','����ʵ��');
set(g,'FontSize', 14,'FontName','Times New Roman');
dt=1:1:10;

% plot(dt,Occupy.Rate,'g*');
% xlabel('ƽ���ݼ�ʱ��\it\rm','FontSize',14,'fontname','Times New Roman');
% ylabel('�ŵ�ռ����\it\rm','FontSize',14,'fontname','Times New Roman'); 

% plot(dt,Rate.Vacation,'k*');
%  g=legend('��ֵʵ��','����ʵ��');
%  set(g,'FontSize', 14,'FontName','Times New Roman');
% xlabel('���߶�ʱ����ƽ��ʱ�䳤�� \it{E}\rm[\it{\xi}]\rm(ms)','FontSize',14,'fontname','Times New Roman');
% ylabel('������ \it{\zeta}\rm(mJ/ms)','FontSize',14,'fontname','Times New Roman');


%  plot(dt,Pu.Block,'g*');
%  xlabel('ƽ���ݼ�ʱ��\it\rm','FontSize',14,'fontname','Times New Roman');
%  ylabel('pu��������\it\rm','FontSize',14,'fontname','Times New Roman');

%  plot(dt,Su.Throughput,'g*');
%  xlabel('ƽ���ݼ�ʱ��\it\rm','FontSize',14,'fontname','Times New Roman');
%  ylabel('su��������\it\rm','FontSize',14,'fontname','Times New Roman');

 plot(dt,Stay.Su,'k*');
 g=legend('��ֵʵ��','����ʵ��');
 set(g,'FontSize', 14,'FontName','Times New Roman');
 xlabel('���߶�ʱ����ƽ��ʱ�䳤�� \it{E}\rm[\it{\xi}\rm](ms)','FontSize',14,'fontname','Times New Roman');
 ylabel('��֪�û����ݰ���ƽ���ӳ� \it\omega\rm(ms)','FontSize',14,'fontname','Times New Roman');

%  plot(dt,Su.Break,'b*');
%  xlabel('ƽ���ݼ�ʱ��\it\rm','FontSize',14,'fontname','Times New Roman');
%  ylabel('su���ж���\it\rm','FontSize',14,'fontname','Times New Roman');